-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2019 年 09 月 03 日 09:31
-- 服务器版本: 5.5.8
-- PHP 版本: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `ding can`
--
CREATE DATABASE `ding can` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `ding can`;

-- --------------------------------------------------------

--
-- 表的结构 `food`
--

CREATE TABLE IF NOT EXISTS `food` (
  `restaurantID` char(10) CHARACTER SET utf8 NOT NULL,
  `foodID` int(10) NOT NULL,
  `food` char(10) CHARACTER SET utf8 NOT NULL,
  `price` int(4) NOT NULL,
  KEY `restaurantID` (`restaurantID`),
  KEY `foodID` (`foodID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `food`
--

INSERT INTO `food` (`restaurantID`, `foodID`, `food`, `price`) VALUES
('0001', 1, '拉面', 48),
('0001', 2, '沙拉', 20),
('0001', 3, '牛舌', 68),
('0002', 1, '金牌蒜香排骨', 88),
('0002', 2, '金牌片皮鸭', 178),
('0002', 3, '松鼠鱼', 150);

-- --------------------------------------------------------

--
-- 表的结构 `orderfood`
--

CREATE TABLE IF NOT EXISTS `orderfood` (
  `ordernumber` int(10) NOT NULL,
  `food` char(10) CHARACTER SET utf8 NOT NULL,
  `price` int(4) NOT NULL,
  `restaurantID` char(10) CHARACTER SET latin1 NOT NULL,
  KEY `ordernumber` (`ordernumber`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_estonian_ci;

--
-- 转存表中的数据 `orderfood`
--


-- --------------------------------------------------------

--
-- 表的结构 `orderlist`
--

CREATE TABLE IF NOT EXISTS `orderlist` (
  `username` int(4) NOT NULL,
  `ordernumber` int(10) NOT NULL,
  UNIQUE KEY `ordernumber` (`ordernumber`),
  KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `orderlist`
--


-- --------------------------------------------------------

--
-- 表的结构 `restaurant`
--

CREATE TABLE IF NOT EXISTS `restaurant` (
  `restaurantID` char(10) NOT NULL,
  `restaurant` char(10) CHARACTER SET utf8 NOT NULL,
  `restaurantAddress` char(10) CHARACTER SET utf8 NOT NULL,
  `restaurantTel` int(10) NOT NULL,
  KEY `restaurantID` (`restaurantID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `restaurant`
--

INSERT INTO `restaurant` (`restaurantID`, `restaurant`, `restaurantAddress`, `restaurantTel`) VALUES
('0001', '小川料理', '江汉路', 85768666),
('0002', '亢龙太子酒轩', '南湖大道', 5561907);

-- --------------------------------------------------------

--
-- 表的结构 `shopcar`
--

CREATE TABLE IF NOT EXISTS `shopcar` (
  `username` int(4) NOT NULL,
  `ordernumber` int(10) NOT NULL,
  `foodID` int(10) NOT NULL,
  `restaurantID` char(10) NOT NULL,
  KEY `username` (`username`),
  KEY `ordernumber` (`ordernumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `shopcar`
--


-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `username` int(4) NOT NULL,
  `truename` char(10) CHARACTER SET utf8 NOT NULL,
  `address` char(10) CHARACTER SET utf8 NOT NULL,
  `tel` int(10) NOT NULL,
  `password` int(10) NOT NULL,
  KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`username`, `truename`, `address`, `tel`, `password`) VALUES
(1234, 'whm', 'hzau', 2147483647, 123);
